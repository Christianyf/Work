#ifndef __CONTROL_H__
#define __CONTROL_H__

#include "mbed.h"
#include "mbed_events.h"


void IRQ_Ticker(void);
#endif