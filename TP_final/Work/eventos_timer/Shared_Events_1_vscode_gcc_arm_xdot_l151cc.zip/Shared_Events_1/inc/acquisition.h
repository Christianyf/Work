#ifndef __ACQUISITION_H__
#define __ACQUISITION_H__

#include "mbed.h"
#include "mbed_events.h"

void MEF_Acquisition(int);
#endif