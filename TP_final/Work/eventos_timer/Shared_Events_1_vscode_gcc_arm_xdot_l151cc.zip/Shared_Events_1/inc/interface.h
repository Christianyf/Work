#ifndef __INTERFACE_H__
#define __INTERFACE_H__

#include "mbed.h"
#include "mbed_events.h"

void MEF_Interface(int);
#endif