#ifndef __COMUNICATION_H__
#define __COMUNICATION_H__

#include "mbed.h"
#include "mbed_events.h"

void MEF_Comunication(int);
#endif